###################
UI / UX 
I choose to designed it as minimalist as posible because I know japan is famous for minimalism also for travelers who uses phone a lot instead of laptop/PC's they need to get or view the weather and attractions as soon as posible.
Fonts are not that big or small specially for the users who uses small screen devices.

Code Implementation
I used Codeigniter 3 for PHP Framework
Bootstrap 5 for Front End
MySQL for database
I used my customized Controller and Model for ease access and calling of functions and queries
see 
/application/core/MY_Controller.php
/application/core/MY_Model.php

Ajax Function for weather located in 
/application/controllers/Ajax.php

Functions for weather and venue API's located in
/application/helpers/custom_functions.php
I used PHP Curl to call the API's
###################