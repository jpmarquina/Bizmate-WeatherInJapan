
	</div> 
	<!-- end div #app .main-controller-wrapper -->

</body>
<script src="<?php print base_url () . "assets/js/jquery-1.9.1.js"; ?>"></script>
<script src="<?php print base_url () . "assets/js/main.js"; ?>"></script>
</html>