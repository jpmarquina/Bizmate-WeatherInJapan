<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Weather in Japan</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<link href="<?php print SITE_BASE_URL . "assets/fontawesome/css/fontawesome.css"; ?>" rel="stylesheet">
<link href="<?php print SITE_BASE_URL . "assets/fontawesome/css/brands.css"; ?>" rel="stylesheet">
<link href="<?php print SITE_BASE_URL . "assets/fontawesome/css/solid.css"; ?>" rel="stylesheet">
<link href="<?php print base_url () . "assets/css/main.css"; ?>" rel="stylesheet" />
<script>
baseURL 	= '<?php print base_url (); ?>';
ajaxURL		= baseURL + 'ajax/requests/';
city_name	= '<?php print $city_name; ?>';
</script>
</head>
<body class="loading">

	<div id="app" class="main-container-wrapper">